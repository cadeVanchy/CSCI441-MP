
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "C:/Users/rogue/Pictures/Saved Pictures/schul/computer graphics/MP/CadeHero.cpp" "CMakeFiles/MP.dir/CadeHero.cpp.obj" "gcc" "CMakeFiles/MP.dir/CadeHero.cpp.obj.d"
  "C:/Users/rogue/Pictures/Saved Pictures/schul/computer graphics/MP/ChaseHero.cpp" "CMakeFiles/MP.dir/ChaseHero.cpp.obj" "gcc" "CMakeFiles/MP.dir/ChaseHero.cpp.obj.d"
  "C:/Users/rogue/Pictures/Saved Pictures/schul/computer graphics/MP/LHMHero.cpp" "CMakeFiles/MP.dir/LHMHero.cpp.obj" "gcc" "CMakeFiles/MP.dir/LHMHero.cpp.obj.d"
  "C:/Users/rogue/Pictures/Saved Pictures/schul/computer graphics/MP/LightingShader.cpp" "CMakeFiles/MP.dir/LightingShader.cpp.obj" "gcc" "CMakeFiles/MP.dir/LightingShader.cpp.obj.d"
  "C:/Users/rogue/Pictures/Saved Pictures/schul/computer graphics/MP/MPEngine.cpp" "CMakeFiles/MP.dir/MPEngine.cpp.obj" "gcc" "CMakeFiles/MP.dir/MPEngine.cpp.obj.d"
  "C:/Users/rogue/Pictures/Saved Pictures/schul/computer graphics/MP/main.cpp" "CMakeFiles/MP.dir/main.cpp.obj" "gcc" "CMakeFiles/MP.dir/main.cpp.obj.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
