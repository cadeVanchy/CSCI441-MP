#version 410 core

// Skybox Vertex Shader
// Renders the unit cube centered around the camera and uses the vertex
// position itself as the 3D direction vector to sample the cube map.

// uniform inputs
uniform mat4 viewMatrix;                // current camera view matrix
uniform mat4 projMatrix;                // current projection matrix

// attribute inputs
layout(location = 0) in vec3 vPos;      // cube vertex position in object space

// varying outputs
layout(location = 0) out vec3 texCoords; // 3D direction vector for cubemap lookup

void main() {
    // the local position on the cube doubles as our 3D cubemap texture coordinate
    texCoords = vPos;

    // strip translation from the view matrix (by casting to mat3 and back to mat4)
    // so the skybox never gets closer or further away when the camera moves
    vec4 pos = projMatrix * mat4(mat3(viewMatrix)) * vec4(vPos, 1.0);

    // set z = w so after perspective divide the depth is always 1.0 (furthest back)
    gl_Position = pos.xyww;
}
