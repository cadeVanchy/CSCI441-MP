#version 410 core

// Skybox Fragment Shader
// Samples the cube map texture using the interpolated 3D direction vector.

// varying inputs
layout(location = 0) in vec3 texCoords; // interpolated 3D direction vector

// uniform inputs
uniform samplerCube skybox;             // cube map texture sampler

// outputs
out vec4 fragColorOut;                  // final skybox color for this fragment

void main() {
    fragColorOut = texture(skybox, texCoords);
}
