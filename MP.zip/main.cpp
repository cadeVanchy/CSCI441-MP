/*
 *  CSCI 441, Computer Graphics, Fall 2026
 *
 *  Project: MP
 *  File: main.cpp
 *
 *  Description:
 *      This file contains the basic setup to render a 3D Hero environment
 *      with Gouraud Phong shading, an Arcball camera, and a Sky Cam viewport.
 *
 *  Author: Dr. Paone, Colorado School of Mines
 *
 */

#define CSCI441_OPENGL_ENGINE_IMPLEMENTATION
#include "MPEngine.h"

#include <CSCI441/LogUtils.hpp>

///*****************************************************************************
//
// Our main function
int main() {
    CSCI441::LogUtils::setLogFilename("MP.log");
    CSCI441::LogUtils::resetLogFile();

    const auto labEngine = new MPEngine();
    labEngine->initialize();
    if (labEngine->getError() == CSCI441::OpenGLEngine::OPENGL_ENGINE_ERROR_NO_ERROR) {
        labEngine->run();
    }
    labEngine->shutdown();
    delete labEngine;

    return EXIT_SUCCESS;
}
