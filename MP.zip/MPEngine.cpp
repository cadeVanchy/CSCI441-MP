#include "MPEngine.h"

#include <CSCI441/objects.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <vector>

// Helper Functions

#ifndef M_PI
#define M_PI 3.14159265f
#endif

// return a random float between 0.0f and 1.0f
static GLfloat getRand() {
    return static_cast<GLfloat>(rand()) / static_cast<GLfloat>(RAND_MAX);
}

MPEngine::MPEngine()
    : CSCI441::OpenGLEngine(4, 1, 1280, 720, "mp: 3D LHM Environment"),
      _mousePosition( glm::vec2(MOUSE_UNINITIALIZED, MOUSE_UNINITIALIZED) ),
      _leftMouseButtonState( GLFW_RELEASE ),
      _camRadius( 10.0f ),
      _camTheta( M_PI / 2.0f ),
      _camPhi( 0.5f ),
      _activeMainCamera( 1 ),
      _showFirstPersonPiP( true ),
      _freeCamPos( glm::vec3(0.0f, 6.0f, -14.0f) ),
      _freeCamTheta( 0.0f ),
      _freeCamPhi( -0.25f ),
      _freeCamSpeed( 0.25f ),
      _activeHeroIndex( 0 ),
      _lhmHero( nullptr ),
      _chaseHero( nullptr ),
      _cadeHero( nullptr ),
      _chaseHeroHeading( 0.0f ),
      _lightingShader( nullptr ),
      _skyboxShaderProgram( nullptr ),
      _skyboxViewMtxLoc( -1 ),
      _skyboxProjMtxLoc( -1 ),
      _skyboxSamplerLoc( -1 ),
      _skyboxTexHandle( 0 )
{
    for(auto& _key : _keys) _key = GL_FALSE;

    // Generate random trees for the world (avoiding the center spawn area)
    for(int i = 0; i < 25; i++) {
        float tx = (getRand() * (WORLD_BOUND * 2.0f - 4.0f)) - (WORLD_BOUND - 2.0f);
        float tz = (getRand() * (WORLD_BOUND * 2.0f - 4.0f)) - (WORLD_BOUND - 2.0f);
        if(fabs(tx) < 4.5f && fabs(tz) < 4.5f) continue;
        _treePositions.emplace_back(tx, 0.0f, tz);
    }

    // Generate buildings of different sizes around the world
    for(int i = 0; i < 15; i++) {
        float bx = (getRand() * (WORLD_BOUND * 2.0f - 6.0f)) - (WORLD_BOUND - 3.0f);
        float bz = (getRand() * (WORLD_BOUND * 2.0f - 6.0f)) - (WORLD_BOUND - 3.0f);
        if(fabs(bx) < 6.0f && fabs(bz) < 6.0f) continue;

        float width = 1.2f + getRand() * 1.8f;
        float depth = 1.2f + getRand() * 1.8f;
        float height = 2.0f + getRand() * 6.0f;

        glm::mat4 modelMtx = glm::translate(glm::mat4(1.0f), glm::vec3(bx, height / 2.0f, bz));
        modelMtx = glm::scale(modelMtx, glm::vec3(width, height, depth));

        glm::vec3 color(0.35f + getRand() * 0.45f,
                        0.35f + getRand() * 0.45f,
                        0.40f + getRand() * 0.45f);
        _buildings.push_back({modelMtx, color, glm::vec3(bx, height / 2.0f, bz), glm::vec3(width, height, depth)});
    }
}

glm::vec3 MPEngine::_getFreeCamLookDir() const {
    return glm::normalize(glm::vec3(
        cos(_freeCamPhi) * sin(_freeCamTheta),
        sin(_freeCamPhi),
        cos(_freeCamPhi) * cos(_freeCamTheta)
    ));
}

glm::vec3 MPEngine::_getActiveHeroPosition() const {
    glm::vec3 localPos(0.0f);
    if(_activeHeroIndex == 1 && _chaseHero) {
        localPos = _chaseHero->getPosition();
    } else if(_activeHeroIndex == 2 && _cadeHero) {
        localPos = _cadeHero->getPosition();
    } else if(_lhmHero) {
        localPos = _lhmHero->getPosition();
    }
    glm::mat4 slopeRot = glm::rotate(glm::mat4(1.0f), -0.12f, glm::vec3(1.0f, 0.0f, 0.0f));
    return glm::vec3(slopeRot * glm::vec4(localPos, 1.0f));
}

glm::vec3 MPEngine::_getActiveHeroForward() const {
    glm::vec3 flatForward(0.0f, 0.0f, 1.0f);
    if(_activeHeroIndex == 1 && _chaseHero) {
        flatForward = glm::vec3(sin(_chaseHeroHeading), 0.0f, cos(_chaseHeroHeading));
    } else if(_activeHeroIndex == 2 && _cadeHero) {
        flatForward = _cadeHero->getForward();
    } else if(_lhmHero) {
        flatForward = _lhmHero->getForward();
    }
    glm::mat4 slopeRot = glm::rotate(glm::mat4(1.0f), -0.12f, glm::vec3(1.0f, 0.0f, 0.0f));
    return glm::normalize(glm::vec3(slopeRot * glm::vec4(flatForward, 0.0f)));
}

glm::vec3 MPEngine::_getActiveHeroEyePosition() const {
    glm::vec3 localEye(0.0f, 2.0f, 0.0f);
    if(_activeHeroIndex == 1 && _chaseHero) {
        glm::vec3 flatForward(sin(_chaseHeroHeading), 0.0f, cos(_chaseHeroHeading));
        localEye = _chaseHero->getPosition() + glm::vec3(0.0f, 1.35f, 0.0f) + flatForward * 0.55f;
    } else if(_activeHeroIndex == 2 && _cadeHero) {
        localEye = _cadeHero->getEyePosition();
    } else if(_lhmHero) {
        localEye = _lhmHero->getEyePosition();
    }
    glm::mat4 slopeRot = glm::rotate(glm::mat4(1.0f), -0.12f, glm::vec3(1.0f, 0.0f, 0.0f));
    return glm::vec3(slopeRot * glm::vec4(localEye, 1.0f));
}

void MPEngine::handleKeyEvent(const GLint key, const GLint action) {
    if(key != GLFW_KEY_UNKNOWN)
        _keys[key] = ((action == GLFW_PRESS) || (action == GLFW_REPEAT));

    if(action == GLFW_PRESS) {
        switch( key ) {
            // quit!
            case GLFW_KEY_Q:
            case GLFW_KEY_ESCAPE:
                setWindowShouldClose();
                break;

            // toggle between available cameras starting from 1 going right
            case GLFW_KEY_1:
                _activeMainCamera = 1; // Arc ball Camera
                break;
            case GLFW_KEY_2:
                _activeMainCamera = 2; // Free Camera
                break;
            case GLFW_KEY_3:
                _showFirstPersonPiP = !_showFirstPersonPiP; // First Person PiP toggle
                break;
            case GLFW_KEY_4:
                _activeMainCamera = 4; // Sky Cam
                break;

            // select active hero starting from 0 going left
            case GLFW_KEY_0:
                _activeHeroIndex = 0; // LHM Hero
                break;
            case GLFW_KEY_9:
                _activeHeroIndex = 1; // Chase Hero
                break;
            case GLFW_KEY_8:
                _activeHeroIndex = 2; // Cade Hero
                break;

            default: break; // suppress CLion warning
        }
    }
}

void MPEngine::handleMouseButtonEvent(const GLint button, const GLint action) {
    if( button == GLFW_MOUSE_BUTTON_LEFT ) {
        _leftMouseButtonState = action;
    }
}

void MPEngine::handleCursorPositionEvent(const glm::vec2 currMousePosition) {
    // if mouse hasn't moved in the window, prevent camera from flipping out
    if(fabs(_mousePosition.x - MOUSE_UNINITIALIZED) <= 0.000001f) {
        _mousePosition = currMousePosition;
    }

    // if the left mouse button is being held down while the mouse is moving
    if(_leftMouseButtonState == GLFW_PRESS) {
        if(_activeMainCamera == 2) {
            // if shift is held down, move free cam in/out along view direction
            if( _keys[GLFW_KEY_LEFT_SHIFT] || _keys[GLFW_KEY_RIGHT_SHIFT] ) {
                GLfloat totChgSq = (currMousePosition.x - _mousePosition.x) + (currMousePosition.y - _mousePosition.y);
                _freeCamPos += _getFreeCamLookDir() * (-totChgSq * 0.05f);
            }
            // otherwise rotate the free camera look direction
            else {
                glm::vec2 diff = currMousePosition - _mousePosition;
                _freeCamTheta -= diff.x * 0.005f;
                _freeCamPhi   -= diff.y * 0.005f;

                if(_freeCamPhi >  M_PI / 2.0f - 0.05f) _freeCamPhi =  M_PI / 2.0f - 0.05f;
                if(_freeCamPhi < -M_PI / 2.0f + 0.05f) _freeCamPhi = -M_PI / 2.0f + 0.05f;
            }
        } else {
            // if shift is held down, update the camera radius in/out
            if( _keys[GLFW_KEY_LEFT_SHIFT] || _keys[GLFW_KEY_RIGHT_SHIFT] ) {
                GLfloat totChgSq = (currMousePosition.x - _mousePosition.x) + (currMousePosition.y - _mousePosition.y);
                _camRadius -= totChgSq * 0.05f;
                if(_camRadius < 2.0f) _camRadius = 2.0f;
                if(_camRadius > 50.0f) _camRadius = 50.0f;
            }
            // otherwise rotate the arcball camera around the character
            else {
                glm::vec2 diff = currMousePosition - _mousePosition;
                _camTheta += diff.x * 0.005f;
                _camPhi -= diff.y * 0.005f;

                // clamp phi to prevent camera from flipping upside down
                if(_camPhi > M_PI / 2.0f - 0.1f) _camPhi = M_PI / 2.0f - 0.1f;
                if(_camPhi < 0.1f) _camPhi = 0.1f;
            }
        }
    }

    // update mouse position
    _mousePosition = currMousePosition;
}

void MPEngine::handleScrollEvent(const glm::vec2 offset) {
    // update the camera radius in/out
    if(_activeMainCamera == 2) {
        _freeCamPos += _getFreeCamLookDir() * (offset.y * 0.8f);
    } else {
        _camRadius -= offset.y * 0.5f;
        if(_camRadius < 2.0f) _camRadius = 2.0f;
        if(_camRadius > 50.0f) _camRadius = 50.0f;
    }
}

// Engine Setup

void MPEngine::mSetupGLFW() {
    CSCI441::OpenGLEngine::mSetupGLFW();

    // set our callbacks
    glfwSetKeyCallback(mpWindow, mp_keyboard_callback);
    glfwSetMouseButtonCallback(mpWindow, mp_mouse_button_callback);
    glfwSetCursorPosCallback(mpWindow, mp_cursor_callback);
    glfwSetScrollCallback(mpWindow, mp_scroll_callback);
}

void MPEngine::mSetupOpenGL() {
    glEnable( GL_DEPTH_TEST );                                      // enable depth testing
    glDepthFunc( GL_LESS );                                         // use less than depth test

    glEnable(GL_BLEND);                                             // enable blending
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);              // use one minus blending equation

    glEnable(GL_TEXTURE_CUBE_MAP_SEAMLESS);                         // seamless cube map edges

    glClearColor( 0.2f, 0.6f, 0.8f, 1.0f );                         // clear the frame buffer to sky blue

    glFrontFace(GL_CCW);                                            // the front faces are CCW
    glCullFace(GL_BACK);                                            // cull the back faces
}

void MPEngine::mSetupShaders() {
    _lightingShader = new LightingShader( "shaders/gouraudShader.v.glsl", "shaders/gouraudShader.f.glsl" );

    CSCI441::setVertexAttributeLocations(LightingAttributes::POSITION,
                                         LightingAttributes::NORMAL,
                                         -1);

    _skyboxShaderProgram = new CSCI441::ShaderProgram( "shaders/skyboxShader.v.glsl", "shaders/skyboxShader.f.glsl" );
    _skyboxViewMtxLoc    = _skyboxShaderProgram->getUniformLocation("viewMatrix");
    _skyboxProjMtxLoc    = _skyboxShaderProgram->getUniformLocation("projMatrix");
    _skyboxSamplerLoc    = _skyboxShaderProgram->getUniformLocation("skybox");
}

void MPEngine::mSetupBuffers() {

    glGenVertexArrays( NUM_VAOS, _vaos );
    glGenBuffers( NUM_VAOS, _vbos );
    glGenBuffers( NUM_VAOS, _ibos );

    // ground platform
    _createPlatform(_vaos[VAO_ID::PLATFORM], _vbos[VAO_ID::PLATFORM], _ibos[VAO_ID::PLATFORM], _numVAOPoints[VAO_ID::PLATFORM]);

    // grid of line strips
    _createGrid(_vaos[VAO_ID::GRID], _vbos[VAO_ID::GRID], _numVAOPoints[VAO_ID::GRID]);

    // skybox cube
    _createSkyboxVAO(_vaos[VAO_ID::SKYBOX], _vbos[VAO_ID::SKYBOX], _numVAOPoints[VAO_ID::SKYBOX]);
}

void MPEngine::_createPlatform(const GLuint vao, const GLuint vbo, const GLuint ibo, GLsizei &numVAOPoints) const {
    struct VertexNormalCoordinate {
        GLfloat x, y, z;        // x, y, z position
        GLfloat nx, ny, nz;     // x, y, z normal vector
    };

    const VertexNormalCoordinate platformVertices[4] = {
        { -WORLD_BOUND, 0.0f, -WORLD_BOUND,  0.0f, 1.0f, 0.0f }, // BL
        {  WORLD_BOUND, 0.0f, -WORLD_BOUND,  0.0f, 1.0f, 0.0f }, // BR
        { -WORLD_BOUND, 0.0f,  WORLD_BOUND,  0.0f, 1.0f, 0.0f }, // TL
        {  WORLD_BOUND, 0.0f,  WORLD_BOUND,  0.0f, 1.0f, 0.0f }  // TR
    };

    constexpr GLushort platformIndices[4] = { 0, 2, 1, 3 };
    numVAOPoints = 4;

    glBindVertexArray(vao);

    glBindBuffer( GL_ARRAY_BUFFER, vbo );
    glBufferData( GL_ARRAY_BUFFER, sizeof( platformVertices ), platformVertices, GL_STATIC_DRAW );

    glEnableVertexAttribArray( LightingAttributes::POSITION );
    glVertexAttribPointer( LightingAttributes::POSITION, 3, GL_FLOAT, GL_FALSE, sizeof(VertexNormalCoordinate), nullptr );

    glEnableVertexAttribArray( LightingAttributes::NORMAL );
    glVertexAttribPointer( LightingAttributes::NORMAL, 3, GL_FLOAT, GL_FALSE, sizeof(VertexNormalCoordinate), reinterpret_cast<void*>(sizeof(GLfloat) * 3) );

    glBindBuffer( GL_ELEMENT_ARRAY_BUFFER, ibo );
    glBufferData( GL_ELEMENT_ARRAY_BUFFER, sizeof( platformIndices ), platformIndices, GL_STATIC_DRAW );
}

void MPEngine::_createGrid(const GLuint vao, const GLuint vbo, GLsizei &numVAOPoints) const {
    struct VertexNormalCoordinate {
        GLfloat x, y, z;        // x, y, z position
        GLfloat nx, ny, nz;     // x, y, z normal vector
    };

    std::vector<VertexNormalCoordinate> gridVertices;
    const int bound = static_cast<int>(WORLD_BOUND);

    // Create a continuous line-strip path forming the grid across [-WORLD_BOUND, WORLD_BOUND]
    for(int i = -bound; i <= bound; i++) {
        if((i + bound) % 2 == 0) {
            gridVertices.push_back({static_cast<GLfloat>(i), 0.02f, -WORLD_BOUND, 0.0f, 1.0f, 0.0f});
            gridVertices.push_back({static_cast<GLfloat>(i), 0.02f,  WORLD_BOUND, 0.0f, 1.0f, 0.0f});
        } else {
            gridVertices.push_back({static_cast<GLfloat>(i), 0.02f,  WORLD_BOUND, 0.0f, 1.0f, 0.0f});
            gridVertices.push_back({static_cast<GLfloat>(i), 0.02f, -WORLD_BOUND, 0.0f, 1.0f, 0.0f});
        }
    }
    for(int j = bound; j >= -bound; j--) {
        if((bound - j) % 2 == 0) {
            gridVertices.push_back({ WORLD_BOUND, 0.02f, static_cast<GLfloat>(j), 0.0f, 1.0f, 0.0f});
            gridVertices.push_back({-WORLD_BOUND, 0.02f, static_cast<GLfloat>(j), 0.0f, 1.0f, 0.0f});
        } else {
            gridVertices.push_back({-WORLD_BOUND, 0.02f, static_cast<GLfloat>(j), 0.0f, 1.0f, 0.0f});
            gridVertices.push_back({ WORLD_BOUND, 0.02f, static_cast<GLfloat>(j), 0.0f, 1.0f, 0.0f});
        }
    }

    numVAOPoints = static_cast<GLsizei>(gridVertices.size());

    glBindVertexArray( vao );
    glBindBuffer( GL_ARRAY_BUFFER, vbo );
    glBufferData( GL_ARRAY_BUFFER, numVAOPoints * sizeof(VertexNormalCoordinate), gridVertices.data(), GL_STATIC_DRAW );

    glEnableVertexAttribArray( LightingAttributes::POSITION );
    glVertexAttribPointer( LightingAttributes::POSITION, 3, GL_FLOAT, GL_FALSE, sizeof(VertexNormalCoordinate), nullptr );

    glEnableVertexAttribArray( LightingAttributes::NORMAL );
    glVertexAttribPointer( LightingAttributes::NORMAL, 3, GL_FLOAT, GL_FALSE, sizeof(VertexNormalCoordinate), reinterpret_cast<void*>(sizeof(GLfloat) * 3) );
}

void MPEngine::_createSkyboxVAO(const GLuint vao, const GLuint vbo, GLsizei &numVAOPoints) const {
    constexpr GLfloat skyboxVertices[] = {
        -1.0f,  1.0f, -1.0f,
        -1.0f, -1.0f, -1.0f,
         1.0f, -1.0f, -1.0f,
         1.0f, -1.0f, -1.0f,
         1.0f,  1.0f, -1.0f,
        -1.0f,  1.0f, -1.0f,

        -1.0f, -1.0f,  1.0f,
        -1.0f, -1.0f, -1.0f,
        -1.0f,  1.0f, -1.0f,
        -1.0f,  1.0f, -1.0f,
        -1.0f,  1.0f,  1.0f,
        -1.0f, -1.0f,  1.0f,

         1.0f, -1.0f, -1.0f,
         1.0f, -1.0f,  1.0f,
         1.0f,  1.0f,  1.0f,
         1.0f,  1.0f,  1.0f,
         1.0f,  1.0f, -1.0f,
         1.0f, -1.0f, -1.0f,

        -1.0f, -1.0f,  1.0f,
        -1.0f,  1.0f,  1.0f,
         1.0f,  1.0f,  1.0f,
         1.0f,  1.0f,  1.0f,
         1.0f, -1.0f,  1.0f,
        -1.0f, -1.0f,  1.0f,

        -1.0f,  1.0f, -1.0f,
         1.0f,  1.0f, -1.0f,
         1.0f,  1.0f,  1.0f,
         1.0f,  1.0f,  1.0f,
        -1.0f,  1.0f,  1.0f,
        -1.0f,  1.0f, -1.0f,

        -1.0f, -1.0f, -1.0f,
        -1.0f, -1.0f,  1.0f,
         1.0f, -1.0f, -1.0f,
         1.0f, -1.0f, -1.0f,
        -1.0f, -1.0f,  1.0f,
         1.0f, -1.0f,  1.0f
    };

    numVAOPoints = 36;

    glBindVertexArray( vao );
    glBindBuffer( GL_ARRAY_BUFFER, vbo );
    glBufferData( GL_ARRAY_BUFFER, sizeof(skyboxVertices), skyboxVertices, GL_STATIC_DRAW );

    glEnableVertexAttribArray( LightingAttributes::POSITION );
    glVertexAttribPointer( LightingAttributes::POSITION, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), nullptr );
}

void MPEngine::mSetupTextures() {
    // set up cube map texture for skybox
    glGenTextures(1, &_skyboxTexHandle);
    glBindTexture(GL_TEXTURE_CUBE_MAP, _skyboxTexHandle);

    constexpr int TEX_SIZE = 256;
    std::vector<unsigned char> faceData(TEX_SIZE * TEX_SIZE * 3);
    const glm::vec3 sunDir = glm::normalize(glm::vec3(0.5f, 1.0f, 0.4f));

    for(int face = 0; face < 6; ++face) {
        for(int y = 0; y < TEX_SIZE; ++y) {
            for(int x = 0; x < TEX_SIZE; ++x) {
                float s = (2.0f * (static_cast<float>(x) + 0.5f) / static_cast<float>(TEX_SIZE)) - 1.0f;
                float t = (2.0f * (static_cast<float>(y) + 0.5f) / static_cast<float>(TEX_SIZE)) - 1.0f;

                glm::vec3 dir(0.0f);
                switch(face) {
                    case 0: dir = glm::vec3( 1.0f,   -t,   -s); break; // +X
                    case 1: dir = glm::vec3(-1.0f,   -t,    s); break; // -X
                    case 2: dir = glm::vec3(    s, 1.0f,    t); break; // +Y
                    case 3: dir = glm::vec3(    s,-1.0f,   -t); break; // -Y
                    case 4: dir = glm::vec3(    s,   -t, 1.0f); break; // +Z
                    case 5: dir = glm::vec3(   -s,   -t,-1.0f); break; // -Z
                }
                dir = glm::normalize(dir);

                float azimuth = atan2(dir.z, dir.x);
                float mountainHeight =
                    0.06f * sin(azimuth * 5.0f) +
                    0.04f * cos(azimuth * 11.0f + 1.2f) +
                    0.025f * sin(azimuth * 23.0f) + 0.03f;

                glm::vec3 color;
                if(dir.y < -0.02f) {
                    float groundBlend = glm::clamp(-dir.y * 4.0f, 0.0f, 1.0f);
                    color = glm::mix(glm::vec3(0.22f, 0.28f, 0.20f), glm::vec3(0.10f, 0.16f, 0.10f), groundBlend);
                } else if(dir.y < mountainHeight) {
                    float ridgeT = glm::clamp((dir.y + 0.02f) / (mountainHeight + 0.02f), 0.0f, 1.0f);
                    color = glm::mix(glm::vec3(0.20f, 0.25f, 0.34f), glm::vec3(0.32f, 0.38f, 0.50f), ridgeT);
                } else {
                    float skyT = powf(glm::clamp(dir.y, 0.0f, 1.0f), 0.55f);
                    color = glm::mix(glm::vec3(0.76f, 0.84f, 0.94f), glm::vec3(0.14f, 0.34f, 0.68f), skyT);

                    if(dir.y > 0.08f) {
                        float u = dir.x / (dir.y + 0.25f);
                        float v = dir.z / (dir.y + 0.25f);
                        float cloudPattern = sin(u * 2.5f + cos(v * 2.1f)) * cos(v * 2.7f - sin(u * 1.9f));
                        float cloudAlpha = glm::smoothstep(0.25f, 0.75f, cloudPattern) *
                                           glm::smoothstep(0.08f, 0.30f, dir.y) * 0.45f;
                        color = glm::mix(color, glm::vec3(0.96f, 0.97f, 1.0f), cloudAlpha);
                    }

                    float sunDot = glm::max(glm::dot(dir, sunDir), 0.0f);
                    color += glm::vec3(1.0f, 0.85f, 0.55f) * (powf(sunDot, 16.0f) * 0.35f);
                    color += glm::vec3(1.0f, 0.98f, 0.90f) * glm::smoothstep(0.996f, 0.9992f, sunDot);
                }

                color = glm::clamp(color, 0.0f, 1.0f);
                int idx = (y * TEX_SIZE + x) * 3;
                faceData[idx + 0] = static_cast<unsigned char>(color.r * 255.0f);
                faceData[idx + 1] = static_cast<unsigned char>(color.g * 255.0f);
                faceData[idx + 2] = static_cast<unsigned char>(color.b * 255.0f);
            }
        }

        glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_X + face,
                     0, GL_RGB, TEX_SIZE, TEX_SIZE, 0,
                     GL_RGB, GL_UNSIGNED_BYTE, faceData.data());
    }

    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE);
}

void MPEngine::mSetupScene() {

    if(!_lightingShader) {
        return;
    }

    // set up light info
    _lightingShader->useProgram();
    _lightingShader->setupDefaultLights();

    const GLuint progHandle = _lightingShader->getShaderProgramHandle();
    const LightingUniformLocations& locs = _lightingShader->getUniformLocations();

    // set up all three heroes side-by-side in the center spawn area
    _lhmHero = new LHMHero(progHandle, locs);
    _lhmHero->setPosition(glm::vec3(-2.5f, 0.5f, 0.0f));

    _chaseHero = new ChaseHero(progHandle, locs);
    _chaseHeroHeading = 0.0f;

    _cadeHero = new CadeHero(progHandle, locs, WORLD_BOUND - 0.5f);
    _cadeHero->setPosition(glm::vec3(2.5f, 0.0f, 0.0f));
}

void MPEngine::mSetupFonts() {
    // Pulled from Lab07
}

// Engine Cleanup

void MPEngine::mCleanupShaders() {
    CSCI441::LogUtils::log("[INFO]: ...deleting Shaders.\n" );
    delete _lightingShader;
    _lightingShader = nullptr;

    delete _skyboxShaderProgram;
    _skyboxShaderProgram = nullptr;
}

void MPEngine::mCleanupBuffers() {
    CSCI441::LogUtils::log("[INFO]: ...deleting VAOs....\n" );
    CSCI441::deleteObjectVAOs();
    glDeleteVertexArrays( NUM_VAOS, _vaos );

    CSCI441::LogUtils::log("[INFO]: ...deleting VBOs....\n" );
    CSCI441::deleteObjectVBOs();
    glDeleteBuffers( NUM_VAOS, _vbos );

    CSCI441::LogUtils::log("[INFO]: ...deleting IBOs....\n" );
    glDeleteBuffers( NUM_VAOS, _ibos );
}

void MPEngine::mCleanupTextures() {
    CSCI441::LogUtils::log("[INFO]: ...deleting Textures\n" );
    if(_skyboxTexHandle != 0) {
        glDeleteTextures(1, &_skyboxTexHandle);
        _skyboxTexHandle = 0;
    }
}

void MPEngine::mCleanupScene() {
    CSCI441::LogUtils::log("[INFO]: ...deleting scene...\n" );
    delete _lhmHero;
    _lhmHero = nullptr;

    delete _chaseHero;
    _chaseHero = nullptr;

    delete _cadeHero;
    _cadeHero = nullptr;
}

void MPEngine::mCleanupFonts() {
    // Pulled from Lab07
}

// Rendering / Drawing

void MPEngine::_drawSkybox(const glm::mat4& viewMtx, const glm::mat4& projMtx) const {
    if(!_skyboxShaderProgram || _skyboxTexHandle == 0) {
        return;
    }

    glDepthFunc(GL_LEQUAL);
    glDepthMask(GL_FALSE);

    _skyboxShaderProgram->useProgram();
    glProgramUniformMatrix4fv(_skyboxShaderProgram->getShaderProgramHandle(), _skyboxViewMtxLoc, 1, GL_FALSE, glm::value_ptr(viewMtx));
    glProgramUniformMatrix4fv(_skyboxShaderProgram->getShaderProgramHandle(), _skyboxProjMtxLoc, 1, GL_FALSE, glm::value_ptr(projMtx));
    glProgramUniform1i(_skyboxShaderProgram->getShaderProgramHandle(), _skyboxSamplerLoc, 0);

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_CUBE_MAP, _skyboxTexHandle);

    glBindVertexArray( _vaos[VAO_ID::SKYBOX] );
    glDrawArrays( GL_TRIANGLES, 0, _numVAOPoints[VAO_ID::SKYBOX] );

    glDepthMask(GL_TRUE);
    glDepthFunc(GL_LESS);
}

void MPEngine::_drawWorld(const glm::mat4& viewMtx, const glm::mat4& projMtx) const {
    glm::mat4 identityMtx(1.0f);

    // Draw Ground Platform
    _lightingShader->setMaterial(glm::vec3(0.15f, 0.45f, 0.15f), glm::vec3(0.03f, 0.09f, 0.03f), glm::vec3(0.15f), 16.0f);
    _lightingShader->sendMatrices(identityMtx, viewMtx, projMtx);
    glBindVertexArray( _vaos[VAO_ID::PLATFORM] );
    glDrawElements( GL_TRIANGLE_STRIP, _numVAOPoints[VAO_ID::PLATFORM], GL_UNSIGNED_SHORT, nullptr );

    // Draw Ground Grid of Line Strips
    _lightingShader->setMaterial(glm::vec3(0.35f, 0.65f, 0.35f), glm::vec3(0.07f, 0.13f, 0.07f), glm::vec3(0.2f), 16.0f);
    _lightingShader->sendMatrices(identityMtx, viewMtx, projMtx);
    glBindVertexArray( _vaos[VAO_ID::GRID] );
    glDrawArrays( GL_LINE_STRIP, 0, _numVAOPoints[VAO_ID::GRID] );

    // Draw Trees
    for(const auto& pos : _treePositions) {
        // Trunk
        _lightingShader->setMaterial(glm::vec3(0.45f, 0.25f, 0.05f), glm::vec3(0.09f, 0.05f, 0.01f), glm::vec3(0.2f), 16.0f);
        glm::mat4 trunk = glm::translate(glm::mat4(1.0f), pos);
        _lightingShader->sendMatrices(trunk, viewMtx, projMtx);
        CSCI441::drawSolidCylinder(0.3f, 0.3f, 2.0f, 16, 16);

        // Leaves
        _lightingShader->setMaterial(glm::vec3(0.05f, 0.65f, 0.15f), glm::vec3(0.01f, 0.13f, 0.03f), glm::vec3(0.3f), 32.0f);
        glm::mat4 leaves = glm::translate(glm::mat4(1.0f), pos + glm::vec3(0.0f, 2.0f, 0.0f));
        _lightingShader->sendMatrices(leaves, viewMtx, projMtx);
        CSCI441::drawSolidCone(1.2f, 2.5f, 16, 16);
    }

    // Draw Buildings
    for(const auto& building : _buildings) {
        _lightingShader->setMaterial(building.color, building.color * 0.2f, glm::vec3(0.5f), 32.0f);
        _lightingShader->sendMatrices(building.modelMatrix, viewMtx, projMtx);
        CSCI441::drawSolidCube(1.0f);
    }
}

void MPEngine::_renderScene(const glm::mat4& viewMtx, const glm::mat4& projMtx) const {
    if(!_lightingShader) {
        return;
    }

    _drawSkybox(viewMtx, projMtx);

    // tilt the floor and all objects/heroes on it so heroes move along and orient with the slope
    const glm::mat4 slopeMtx = glm::rotate(glm::mat4(1.0f), -0.12f, glm::vec3(1.0f, 0.0f, 0.0f));
    const glm::mat4 slopedViewMtx = viewMtx * slopeMtx;

    // use the gouraud shader
    _lightingShader->useProgram();

    _drawWorld(slopedViewMtx, projMtx);

    if(_lhmHero) {
        _lhmHero->draw(slopedViewMtx, projMtx);
    }
    if(_chaseHero) {
        _chaseHero->draw(slopedViewMtx, projMtx);
    }
    if(_cadeHero) {
        _cadeHero->draw(slopedViewMtx, projMtx);
    }
}

bool MPEngine::_collidesWithWorld(const glm::vec3& pos, const GLfloat radius) const {
    // Basic collision detection with trees and buildings
    constexpr GLfloat TREE_RADIUS = 0.5f;

    for(const auto& treePos : _treePositions) {
        GLfloat dx = pos.x - treePos.x;
        GLfloat dz = pos.z - treePos.z;
        if((dx * dx + dz * dz) < (radius + TREE_RADIUS) * (radius + TREE_RADIUS)) {
            return true;
        }
    }

    for(const auto& building : _buildings) {
        if(fabs(pos.x - building.position.x) < (building.size.x * 0.5f + radius) &&
           fabs(pos.z - building.position.z) < (building.size.z * 0.5f + radius)) {
            return true;
        }
    }

    return false;
}

void MPEngine::_updateScene() {
    const bool freeCamActive = (_activeMainCamera == 2);

    if(freeCamActive) {
        glm::vec3 lookDir  = _getFreeCamLookDir();
        glm::vec3 rightDir = glm::normalize(glm::cross(lookDir, glm::vec3(0.0f, 1.0f, 0.0f)));

        if(_keys[GLFW_KEY_W]) _freeCamPos += lookDir * _freeCamSpeed;
        if(_keys[GLFW_KEY_S]) _freeCamPos -= lookDir * _freeCamSpeed;
        if(_keys[GLFW_KEY_D]) _freeCamPos += rightDir * _freeCamSpeed;
        if(_keys[GLFW_KEY_A]) _freeCamPos -= rightDir * _freeCamSpeed;
    }

    const bool moveForward  = _keys[GLFW_KEY_UP]    || (!freeCamActive && _keys[GLFW_KEY_W]);
    const bool moveBackward = _keys[GLFW_KEY_DOWN]  || (!freeCamActive && _keys[GLFW_KEY_S]);
    const bool turnLeft     = _keys[GLFW_KEY_LEFT]  || (!freeCamActive && _keys[GLFW_KEY_A]);
    const bool turnRight    = _keys[GLFW_KEY_RIGHT] || (!freeCamActive && _keys[GLFW_KEY_D]);

    if(_lhmHero) {
        _lhmHero->setMoving(false);
    }
    if(_cadeHero) {
        _cadeHero->setMoving(false);
    }

    // 'w' moves forward along heading, 's' moves backward along heading
    // 'a' turns heading left, 'd' turns heading right
    if(_activeHeroIndex == 1 && _chaseHero) {
        if(moveForward) {
            _chaseHero->moveForward();
            if(_collidesWithWorld(_chaseHero->getPosition(), 0.6f)) {
                _chaseHero->moveBackward();
            }
        }
        if(moveBackward) {
            _chaseHero->moveBackward();
            if(_collidesWithWorld(_chaseHero->getPosition(), 0.6f)) {
                _chaseHero->moveForward();
            }
        }
        if(turnLeft)  { _chaseHero->turnLeft();  _chaseHeroHeading += 0.04f; }
        if(turnRight) { _chaseHero->turnRight(); _chaseHeroHeading -= 0.04f; }
    } else if(_activeHeroIndex == 2 && _cadeHero) {
        glm::vec3 prevPos = _cadeHero->getPosition();
        if(moveForward)  { _cadeHero->moveForward(0.1f);  _cadeHero->setMoving(true); }
        if(moveBackward) { _cadeHero->moveBackward(0.1f); _cadeHero->setMoving(true); }
        if(turnLeft)     { _cadeHero->turn(0.042f); }
        if(turnRight)    { _cadeHero->turn(-0.042f); }

        if(_collidesWithWorld(_cadeHero->getPosition(), 0.6f)) {
            _cadeHero->setPosition(prevPos);
        }
    } else if(_lhmHero) {
        glm::vec3 prevPos = _lhmHero->getPosition();
        if(moveForward)  _lhmHero->moveForward();
        if(moveBackward) _lhmHero->moveBackward();
        if(turnLeft)     _lhmHero->turnLeft();
        if(turnRight)    _lhmHero->turnRight();

        if(_collidesWithWorld(_lhmHero->getPosition(), 0.6f)) {
            _lhmHero->setPosition(prevPos);
        }
    }

    // Advance animation timers
    if(_lhmHero) {
        _lhmHero->update();
    }
    if(_cadeHero) {
        _cadeHero->update();
    }
}

void MPEngine::run() {

    while( !glfwWindowShouldClose(mpWindow) ) {
        glDrawBuffer( GL_BACK );
        glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

        // Get the size of our framebuffer.
        GLint framebufferWidth, framebufferHeight;
        glfwGetFramebufferSize( mpWindow, &framebufferWidth, &framebufferHeight );
        if(framebufferHeight <= 0) framebufferHeight = 1;

        glm::vec3 activeHeroPos     = _getActiveHeroPosition();
        glm::vec3 activeHeroForward = _getActiveHeroForward();
        glm::vec3 activeHeroEyePos  = _getActiveHeroEyePosition();

        // Arc ball camera
        float camX = activeHeroPos.x + _camRadius * cos(_camPhi) * sin(_camTheta);
        float camY = activeHeroPos.y + _camRadius * sin(_camPhi);
        float camZ = activeHeroPos.z + _camRadius * cos(_camPhi) * cos(_camTheta);
        glm::vec3 arcCamPos(camX, camY, camZ);
        glm::mat4 arcballView = glm::lookAt(arcCamPos, activeHeroPos + glm::vec3(0.0f, 1.5f, 0.0f), glm::vec3(0.0f, 1.0f, 0.0f));

        // Free Camera
        glm::vec3 freeCamLookDir = _getFreeCamLookDir();
        glm::mat4 freeCamView = glm::lookAt(_freeCamPos, _freeCamPos + freeCamLookDir, glm::vec3(0.0f, 1.0f, 0.0f));

        // First Person Camera
        glm::mat4 firstPersonView = glm::lookAt(activeHeroEyePos, activeHeroEyePos + activeHeroForward, glm::vec3(0.0f, 1.0f, 0.0f));

        // Sky Camera
        glm::vec3 skyCamPos = activeHeroPos + glm::vec3(0.0f, 25.0f, 0.0f);
        glm::mat4 skyView = glm::lookAt(skyCamPos, activeHeroPos, activeHeroForward);

        glm::mat4 mainProjection = glm::perspective(glm::radians(45.0f), static_cast<float>(framebufferWidth) / static_cast<float>(framebufferHeight), 0.1f, 150.0f);
        glm::mat4 pipProjection  = glm::perspective(glm::radians(60.0f), 1.0f, 0.1f, 150.0f);

        // Main Viewport
        glViewport( 0, 0, framebufferWidth, framebufferHeight );
        glm::mat4 mainView = arcballView;
        glm::vec3 mainEye  = arcCamPos;
        if(_activeMainCamera == 2) {
            mainView = freeCamView;
            mainEye  = _freeCamPos;
        } else if(_activeMainCamera == 4) {
            mainView = skyView;
            mainEye  = skyCamPos;
        }

        if(_lightingShader) {
            _lightingShader->useProgram();
            _lightingShader->setEyePosition(mainEye);
        }
        _renderScene(mainView, mainProjection);

        // First-Person PiP Viewport
        if(_showFirstPersonPiP) {
            int pipSize = framebufferHeight / 3;
            glViewport( framebufferWidth - pipSize, framebufferHeight - pipSize, pipSize, pipSize );
            glEnable( GL_SCISSOR_TEST );
            glScissor( framebufferWidth - pipSize, framebufferHeight - pipSize, pipSize, pipSize );
            glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
            glDisable( GL_SCISSOR_TEST );

            if(_lightingShader) {
                _lightingShader->useProgram();
                _lightingShader->setEyePosition(activeHeroEyePos);
            }
            _renderScene(firstPersonView, pipProjection);
        }

        // animate the scene
        _updateScene();

        glfwSwapBuffers(mpWindow);
        glfwPollEvents();
    }
}

// Callbacks

void mp_keyboard_callback(GLFWwindow *window, const int key, const int scancode, const int action, const int mods) {
    if(const auto engine = static_cast<MPEngine *>(glfwGetWindowUserPointer(window))) {
        engine->handleKeyEvent(key, action);
    }
}

void mp_cursor_callback(GLFWwindow *window, const double x, const double y) {
    if(const auto engine = static_cast<MPEngine *>(glfwGetWindowUserPointer(window))) {
        engine->handleCursorPositionEvent(glm::vec2(x, y));
    }
}

void mp_mouse_button_callback(GLFWwindow *window, const int button, const int action, const int mods) {
    if(const auto engine = static_cast<MPEngine *>(glfwGetWindowUserPointer(window))) {
        engine->handleMouseButtonEvent(button, action);
    }
}

void mp_scroll_callback(GLFWwindow *window, const double xOffset, const double yOffset) {
    if(const auto engine = static_cast<MPEngine *>(glfwGetWindowUserPointer(window))) {
        engine->handleScrollEvent(glm::vec2(xOffset, yOffset));
    }
}
