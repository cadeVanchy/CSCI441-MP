#ifndef MP_ENGINE_H
#define MP_ENGINE_H

#include "CadeHero.h"
#include "ChaseHero.h"
#include "LHMHero.h"
#include "LightingShader.h"

#include <CSCI441/OpenGLEngine.hpp>
#include <CSCI441/ShaderProgram.hpp>

#include <glm/glm.hpp>
#include <vector>

class MPEngine final : public CSCI441::OpenGLEngine {
public:
    //***************************************************************************
    // Engine Interface

    MPEngine();
    ~MPEngine() override = default;

    void run() override;

    //***************************************************************************
    // Event Handlers

    void handleKeyEvent(GLint key, GLint action);
    void handleMouseButtonEvent(GLint button, GLint action);
    void handleCursorPositionEvent(glm::vec2 currMousePosition);
    void handleScrollEvent(glm::vec2 offset);

    static constexpr GLfloat MOUSE_UNINITIALIZED = -9999.0f;

protected:
    //***************************************************************************
    // Engine Setup

    void mSetupGLFW() override;
    void mSetupOpenGL() override;
    void mSetupShaders() override;
    void mSetupBuffers() override;
    void mSetupTextures() override;
    void mSetupScene() override;
    void mSetupFonts() override;

    //***************************************************************************
    // Engine Cleanup

    void mCleanupScene() override;
    void mCleanupTextures() override;
    void mCleanupBuffers() override;
    void mCleanupShaders() override;
    void mCleanupFonts() override;

private:
    //***************************************************************************
    // Engine Rendering & Updating

    void _renderScene(const glm::mat4& viewMtx, const glm::mat4& projMtx) const;

    void _updateScene();

    void _drawWorld(const glm::mat4& viewMtx, const glm::mat4& projMtx) const;

    void _drawSkybox(const glm::mat4& viewMtx, const glm::mat4& projMtx) const;

    // Input Tracking (Keyboard & Mouse)
    static constexpr GLuint NUM_KEYS = GLFW_KEY_LAST;
    GLboolean _keys[NUM_KEYS] = {0};

    glm::vec2 _mousePosition;
    GLint _leftMouseButtonState;

    // Camera Information

    GLfloat _camRadius;
    GLfloat _camTheta;
    GLfloat _camPhi;
    int _activeMainCamera;
    bool _showFirstPersonPiP;

    glm::vec3 _freeCamPos;
    GLfloat _freeCamTheta;
    GLfloat _freeCamPhi;
    GLfloat _freeCamSpeed;
    glm::vec3 _getFreeCamLookDir() const;

    // VAO & World Object Information

    static constexpr GLuint NUM_VAOS = 3;
    enum VAO_ID {
        PLATFORM = 0,
        GRID = 1,
        SKYBOX = 2
    };

    GLuint _vaos[NUM_VAOS] = {0};
    GLuint _vbos[NUM_VAOS] = {0};
    GLuint _ibos[NUM_VAOS] = {0};
    GLsizei _numVAOPoints[NUM_VAOS] = {0};

    void _createPlatform(GLuint vao, GLuint vbo, GLuint ibo, GLsizei &numVAOPoints) const;
    void _createGrid(GLuint vao, GLuint vbo, GLsizei &numVAOPoints) const;
    void _createSkyboxVAO(GLuint vao, GLuint vbo, GLsizei &numVAOPoints) const;

    // LHM, Heroes & World Information

    int _activeHeroIndex;
    LHMHero* _lhmHero;
    ChaseHero* _chaseHero;
    CadeHero* _cadeHero;
    GLfloat _chaseHeroHeading;

    static constexpr GLfloat WORLD_BOUND = 25.0f;
    std::vector<glm::vec3> _treePositions;

    struct BuildingData {
        glm::mat4 modelMatrix;
        glm::vec3 color;
        glm::vec3 position;
        glm::vec3 size;
    };
    std::vector<BuildingData> _buildings;

    // Shader Program Information
    LightingShader* _lightingShader;

    CSCI441::ShaderProgram* _skyboxShaderProgram;
    GLint _skyboxViewMtxLoc;
    GLint _skyboxProjMtxLoc;
    GLint _skyboxSamplerLoc;
    GLuint _skyboxTexHandle;

    // Helper Functions
    glm::vec3 _getActiveHeroPosition() const;
    glm::vec3 _getActiveHeroForward() const;
    glm::vec3 _getActiveHeroEyePosition() const;
    bool _collidesWithWorld(const glm::vec3& pos, GLfloat radius) const;
};

void mp_keyboard_callback(GLFWwindow *window, int key, int scancode, int action, int mods);
void mp_cursor_callback(GLFWwindow *window, double x, double y);
void mp_mouse_button_callback(GLFWwindow *window, int button, int action, int mods);
void mp_scroll_callback(GLFWwindow *window, double xOffset, double yOffset);

#endif// MP_ENGINE_H
