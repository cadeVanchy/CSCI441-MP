#ifndef LHM_HERO_H
#define LHM_HERO_H

#include "LightingUniforms.h"

#include <glad/gl.h>
#include <glm/glm.hpp>

// Our LHM character class: a levitating hero with a cube body, green sphere head,
// bulging red eyes, a flowing cape, and swinging arms
class LHMHero {
public:
    //***************************************************************************
    // LHM Hero Interface

    // sets up LHM with the lighting shader handle and shared uniform locations
    LHMHero(GLuint shaderProgramHandle, const LightingUniformLocations& locs);

    // draws the hierarchical LHM character at its current position and heading
    void draw(const glm::mat4& viewMtx, const glm::mat4& projMtx) const;

    // advances idle bobbing and walk animation timers each frame
    void update();

    //***************************************************************************
    // Movement Controls

    // move forward/backward along the current heading
    void moveForward();
    void moveBackward();

    // turn heading left or right
    void turnLeft();
    void turnRight();

    // track whether LHM is actively moving this frame (for limb/cape animation)
    void setMoving(bool moving) { _isMoving = moving; }
    void setPosition(const glm::vec3& pos);

    // getters so the cameras can follow LHM or attach to its eyes
    glm::vec3 getPosition() const { return _position; }
    GLfloat getHeading() const { return _heading; }
    glm::vec3 getForward() const;
    glm::vec3 getEyePosition() const;

private:
    // Phong material properties for one body part
    struct Material {
        glm::vec3 diffuse;
        glm::vec3 ambient;
        glm::vec3 specular;
        GLfloat shininess;
    };

    // Shader Program Information
    GLuint _shaderProgramHandle;
    LightingUniformLocations _uniformLocations;

    // LHM Position & Animation Information
    glm::vec3 _position;
    GLfloat _heading;
    GLfloat _speed;
    bool _isMoving;
    GLfloat _animTime;
    GLfloat _idleTime;

    static constexpr GLfloat TURN_SPEED  = 0.05f;
    static constexpr GLfloat WORLD_BOUND = 24.5f;

    // Helper Functions
    void _setMaterial(const Material& material) const;
    void _computeAndSendMatrixUniforms(const glm::mat4& modelMtx, const glm::mat4& viewMtx, const glm::mat4& projMtx) const;
    void _clampToWorld();
};

#endif// LHM_HERO_H
