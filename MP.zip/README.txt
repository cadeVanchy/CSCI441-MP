Midterm Project (MP): 3D Heroes Environment

Mixed Factions, as we were the last group in the class

Land Members:
  - Alex Rogers (Lord Havemercy)
  - Chase Hardy (Faenor)
  - Cade LaVanchy (Lyriane Shadowheart)

This program renders an interactive 3D world populated with three animated hero characters 
alongside a flat ground platform, a coordinate line-strip grid, and two types of scattered world scenery.
All 3D geometry is lit using a custom Gouraud shading pipeline implementing the
full Phong Reflectance Model (ambient, diffuse, and specular components) with
three additive light sources:
  1) A directional light (warm sunlight across the scene)
  2) An attenuated point light (warm golden glow floating near the center)
  3) An attenuated spotlight (cool overhead)

The entire world is enclosed within a cube-map skybox
(GL_TEXTURE_CUBE_MAP) with linear texture filtering and edge clamping. Users can
switch between multiple camera modes (Arcball Cam, Free Cam, Sky Cam, and a
toggleable First-Person Point-of-View Picture-in-Picture viewport) and dynamically
select which of the three Heroes to control and follow.

USAGE & CONTROLS

Running the Program:
  Run the compiled executable from the project root directory

Camera Controls:
  [1] : Switch main viewport to Arcball Camera
  [2] : Switch main viewport to Free Camera
  [3] : Toggle First-Person POV Camera Picture-in-Picture (PiP) viewport on/off
  [4] : Switch main viewport to Sky Camera

Hero Selection Controls (Number Keys 0 -> Left):
  [0] : Select Lord Havemercy as the active Hero
  [9] : Select Faenor as the active Hero
  [8] : Select Lyriane Shadowheart as the active Hero

Movement Controls:
  When in Arcball Camera [1] or Sky Camera [4]:
    [W] / [Up Arrow]    : Move the active Hero forward along their heading
    [S] / [Down Arrow]  : Move the active Hero backward along their heading
    [A] / [Left Arrow]  : Turn the active Hero left
    [D] / [Right Arrow] : Turn the active Hero right

  When in Free Camera [2]:
    [W] / [S]           : Move the Free Camera forward / backward along view dir
    [A] / [D]           : Strafe the Free Camera left / right
    [Arrow Keys]        : Move and turn the active Hero while watching from Free Cam

Mouse Controls:
  Left-Click + Drag: Orbit Arcball Camera around active Hero (or rotate Free Camera look direction in mode [2])
  Shift + Left-Click + Drag: Zoom Arcball Camera radius in/out (or dolly Free Camera forward/backward in mode [2])
  Mouse Scroll Wheel: Zoom Arcball Camera radius in/out (or dolly Free Camera forward/backward in mode [2])

General Controls:
  [Q] / [ESC]: Quit the application

Details and Notes:
  - All heroes and world objects share the uniform and attribute locations defined in LightingUniforms.h and managed by
    LightingShader (layout location 0 = vPos, layout location 1 = vNormal).
  - Moving heroes are clamped to the platform boundaries and checked for collisions against the generated trees
    and buildings.
  - Skybox uses a GL_TEXTURE_CUBE_MAP texture with GL_LINEAR filtering, GL_CLAMP_TO_EDGE wrapping, and GL_TEXTURE_CUBE_MAP_SEAMLESS
    enabled so all 6 cube faces align without visible seams.

Group Member contributions:
  - Alex Rogers:
      Created Lord Havemercy
      Assembled all files into one coherent piece and implemented the slope

  - Chase Hardy:
      Created Lyriane Shadowheart
      Implemented the shaders and lighting

  - Cade LaVanchy:
      Created Faenor
