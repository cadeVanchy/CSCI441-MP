#include "LHMHero.h"

#include <CSCI441/objects.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <cmath>

LHMHero::LHMHero(const GLuint shaderProgramHandle, const LightingUniformLocations& locs)
    : _shaderProgramHandle( shaderProgramHandle ),
      _uniformLocations( locs ),
      _position( glm::vec3(0.0f, 0.5f, 0.0f) ),
      _heading( 0.0f ),
      _speed( 0.2f ),
      _isMoving( false ),
      _animTime( 0.0f ),
      _idleTime( 0.0f )
{
}

void LHMHero::setPosition(const glm::vec3& pos) {
    // set position and make sure LHM stays inside the world platform
    _position = pos;
    _clampToWorld();
}

glm::vec3 LHMHero::getForward() const {
    // direction LHM is facing on the XZ plane (heading 0 faces +Z)
    return glm::vec3(sin(_heading), 0.0f, cos(_heading));
}

glm::vec3 LHMHero::getEyePosition() const {
    // match the bobbing height of the head and push slightly forward so the
    // first-person camera sits right in front of the eyes without clipping the head
    float idleBob = sin(_idleTime * 2.0f) * 0.04f;
    return _position + glm::vec3(0.0f, 2.55f + idleBob, 0.0f) + getForward() * 0.45f;
}

void LHMHero::moveForward() {
    // step forward along current heading and keep within world bounds
    _position += getForward() * _speed;
    _isMoving = true;
    _clampToWorld();
}

void LHMHero::moveBackward() {
    // step backward along current heading and keep within world bounds
    _position -= getForward() * _speed;
    _isMoving = true;
    _clampToWorld();
}

void LHMHero::turnLeft() {
    // rotate heading to the left
    _heading += TURN_SPEED;
    _isMoving = true;
}

void LHMHero::turnRight() {
    // rotate heading to the right
    _heading -= TURN_SPEED;
    _isMoving = true;
}

void LHMHero::_clampToWorld() {
    // Bounds check so LHM doesn't walk off the edge of the ground plane
    if(_position.x >  WORLD_BOUND) _position.x =  WORLD_BOUND;
    if(_position.x < -WORLD_BOUND) _position.x = -WORLD_BOUND;
    if(_position.z >  WORLD_BOUND) _position.z =  WORLD_BOUND;
    if(_position.z < -WORLD_BOUND) _position.z = -WORLD_BOUND;
}

void LHMHero::update() {
    // Advance animation timers (idle bob always runs, walk cycle runs when moving)
    _idleTime += 0.03f;
    if(_isMoving) _animTime += 0.1f;
}

void LHMHero::draw(const glm::mat4& viewMtx, const glm::mat4& projMtx) const {
    // Levitation/Bobbing
    float idleBob = sin(_idleTime * 2.0f) * 0.04f;
    // swing arms wider when moving, or gently sway while idling
    float limbSwing = _isMoving ? sin(_animTime) * 0.55f : sin(_idleTime * 2.0f) * 0.05f;

    // Root - move to LHM's world position (plus hover bob) and rotate to face heading
    glm::mat4 modelBase = glm::translate(glm::mat4(1.0f), _position + glm::vec3(0.0f, idleBob, 0.0f));
    modelBase = glm::rotate(modelBase, _heading, glm::vec3(0.0f, 1.0f, 0.0f));

    // Body - Child of modelBase (blue torso)
    glm::mat4 bodyBase = glm::translate(modelBase, glm::vec3(0.0f, 1.5f, 0.0f));
    _setMaterial({glm::vec3(0.0f, 0.0f, 0.8f), glm::vec3(0.0f, 0.0f, 0.16f), glm::vec3(0.5f), 32.0f});
    glm::mat4 bodyMtx = glm::scale(bodyBase, glm::vec3(1.0f, 1.5f, 0.5f));
    _computeAndSendMatrixUniforms(bodyMtx, viewMtx, projMtx);
    CSCI441::drawSolidCube(1.0f);

    // Head - Child of bodyBase (green sphere sitting on top of the torso)
    glm::mat4 headBase = glm::translate(bodyBase, glm::vec3(0.0f, 1.0f, 0.1f));
    _setMaterial({glm::vec3(0.0f, 0.75f, 0.1f), glm::vec3(0.0f, 0.15f, 0.02f), glm::vec3(0.5f), 32.0f});
    glm::mat4 headMtx = glm::scale(headBase, glm::vec3(0.6f, 0.6f, 0.6f));
    _computeAndSendMatrixUniforms(headMtx, viewMtx, projMtx);
    CSCI441::drawSolidSphere(0.5f, 16, 16);

    // Bulging Spherical Eyes - Children of headBase (shiny red spheres)
    _setMaterial({glm::vec3(0.9f, 0.0f, 0.0f), glm::vec3(0.18f, 0.0f, 0.0f), glm::vec3(0.8f), 64.0f});
    glm::mat4 leftEyeMtx = glm::translate(headBase, glm::vec3(0.12f, 0.05f, 0.26f));
    _computeAndSendMatrixUniforms(leftEyeMtx, viewMtx, projMtx);
    CSCI441::drawSolidSphere(0.09f, 16, 16);

    glm::mat4 rightEyeMtx = glm::translate(headBase, glm::vec3(-0.12f, 0.05f, 0.26f));
    _computeAndSendMatrixUniforms(rightEyeMtx, viewMtx, projMtx);
    CSCI441::drawSolidSphere(0.09f, 16, 16);

    // Cape - Child of bodyBase (billows up higher when LHM is moving)
    _setMaterial({glm::vec3(0.8f, 0.0f, 0.0f), glm::vec3(0.16f, 0.0f, 0.0f), glm::vec3(0.3f), 16.0f});
    float capeAngle = _isMoving
        ? (0.28f + fabs(sin(_animTime)) * 0.18f)
        : (0.15f + sin(_idleTime * 2.0f) * 0.04f);
    glm::mat4 capeMtx = glm::translate(bodyBase, glm::vec3(0.0f, 0.7f, -0.26f));
    capeMtx = glm::rotate(capeMtx, capeAngle, glm::vec3(1.0f, 0.0f, 0.0f));
    capeMtx = glm::translate(capeMtx, glm::vec3(0.0f, -0.8f, 0.0f));
    capeMtx = glm::scale(capeMtx, glm::vec3(1.1f, 1.6f, 0.05f));
    _computeAndSendMatrixUniforms(capeMtx, viewMtx, projMtx);
    CSCI441::drawSolidCube(1.0f);

    // Left & Right Arms - Children of bodyBase (swing in opposite directions)
    _setMaterial({glm::vec3(0.05f, 0.05f, 0.05f), glm::vec3(0.02f), glm::vec3(0.3f), 16.0f});

    glm::mat4 leftArmMtx = glm::translate(bodyBase, glm::vec3(0.7f, 0.5f, 0.0f));
    leftArmMtx = glm::rotate(leftArmMtx, limbSwing, glm::vec3(1.0f, 0.0f, 0.0f));
    leftArmMtx = glm::translate(leftArmMtx, glm::vec3(0.0f, -0.6f, 0.0f));
    leftArmMtx = glm::scale(leftArmMtx, glm::vec3(0.3f, 1.2f, 0.3f));
    _computeAndSendMatrixUniforms(leftArmMtx, viewMtx, projMtx);
    CSCI441::drawSolidCube(1.0f);

    glm::mat4 rightArmMtx = glm::translate(bodyBase, glm::vec3(-0.7f, 0.5f, 0.0f));
    rightArmMtx = glm::rotate(rightArmMtx, -limbSwing, glm::vec3(1.0f, 0.0f, 0.0f));
    rightArmMtx = glm::translate(rightArmMtx, glm::vec3(0.0f, -0.6f, 0.0f));
    rightArmMtx = glm::scale(rightArmMtx, glm::vec3(0.3f, 1.2f, 0.3f));
    _computeAndSendMatrixUniforms(rightArmMtx, viewMtx, projMtx);
    CSCI441::drawSolidCube(1.0f);
}

void LHMHero::_setMaterial(const Material& material) const {
    // send all four Phong material properties to the lighting shader before drawing
    glProgramUniform3fv(_shaderProgramHandle, _uniformLocations.materialDiffuse, 1, glm::value_ptr(material.diffuse));
    glProgramUniform3fv(_shaderProgramHandle, _uniformLocations.materialAmbient, 1, glm::value_ptr(material.ambient));
    glProgramUniform3fv(_shaderProgramHandle, _uniformLocations.materialSpecular, 1, glm::value_ptr(material.specular));
    glProgramUniform1f(_shaderProgramHandle, _uniformLocations.materialShininess, material.shininess);
}

void LHMHero::_computeAndSendMatrixUniforms(const glm::mat4& modelMtx, const glm::mat4& viewMtx, const glm::mat4& projMtx) const {
    // precompute the MVP matrix CPU side
    const glm::mat4 mvpMatrix = projMtx * viewMtx * modelMtx;
    // precompute the Normal matrix CPU side
    const glm::mat3 normalMatrix = glm::mat3(glm::transpose(glm::inverse(modelMtx)));

    // send the matrices to the shader
    glProgramUniformMatrix4fv(_shaderProgramHandle, _uniformLocations.mvpMtx, 1, GL_FALSE, glm::value_ptr(mvpMatrix));
    glProgramUniformMatrix4fv(_shaderProgramHandle, _uniformLocations.modelMtx, 1, GL_FALSE, glm::value_ptr(modelMtx));
    glProgramUniformMatrix3fv(_shaderProgramHandle, _uniformLocations.normalMtx, 1, GL_FALSE, glm::value_ptr(normalMatrix));
}
